package com.app.alg.judix.model;

/**
 * Created by lucas on 17/03/17.
 */

public class Endereco {
    private String END_ID;
    private String BAI_ID;
    private String END_Cep;
    private String END_Logradouro;
    private String END_Numero;
    private String END_Complemento;
    private String END_PontoReferencia;
    private String END_Municipio;
    private String END_UF;

    public String getEND_ID() {
        return END_ID;
    }

    public void setEND_ID(String END_ID) {
        this.END_ID = END_ID;
    }

    public String getBAI_ID() {
        return BAI_ID;
    }

    public void setBAI_ID(String BAI_ID) {
        this.BAI_ID = BAI_ID;
    }

    public String getEND_Cep() {
        return END_Cep;
    }

    public void setEND_Cep(String END_Cep) {
        this.END_Cep = END_Cep;
    }

    public String getEND_Logradouro() {
        return END_Logradouro;
    }

    public void setEND_Logradouro(String END_Logradouro) {
        this.END_Logradouro = END_Logradouro;
    }

    public String getEND_Numero() {
        return END_Numero;
    }

    public void setEND_Numero(String END_Numero) {
        this.END_Numero = END_Numero;
    }

    public String getEND_Complemento() {
        return END_Complemento;
    }

    public void setEND_Complemento(String END_Complemento) {
        this.END_Complemento = END_Complemento;
    }

    public String getEND_PontoReferencia() {
        return END_PontoReferencia;
    }

    public void setEND_PontoReferencia(String END_PontoReferencia) {
        this.END_PontoReferencia = END_PontoReferencia;
    }

    public String getEND_Municipio() {
        return END_Municipio;
    }

    public void setEND_Municipio(String END_Municipio) {
        this.END_Municipio = END_Municipio;
    }

    public String getEND_UF() {
        return END_UF;
    }

    public void setEND_UF(String END_UF) {
        this.END_UF = END_UF;
    }
}
