package com.app.alg.judix.model;

/**
 * Created by lucas on 08/02/16.
 */
public class Entidade {
    private int ENT_ID;
    private int END_ID;
    private int JUR_ID;
    private String ENT_Vara;
    private String ENT_Comarca;
    private String ENT_Status;
    private String ENT_Forum;
    private String ENT_Tipo;
    private String ENT_Fone;
    private String ENT_Contato;

    public int getENT_ID() {
        return ENT_ID;
    }

    public void setENT_ID(int ENT_ID) {
        this.ENT_ID = ENT_ID;
    }

    public int getEND_ID() {
        return END_ID;
    }

    public void setEND_ID(int END_ID) {
        this.END_ID = END_ID;
    }

    public int getJUR_ID() {
        return JUR_ID;
    }

    public void setJUR_ID(int JUR_ID) {
        this.JUR_ID = JUR_ID;
    }

    public String getENT_Vara() {
        return ENT_Vara;
    }

    public void setENT_Vara(String ENT_Vara) {
        this.ENT_Vara = ENT_Vara;
    }

    public String getENT_Comarca() {
        return ENT_Comarca;
    }

    public void setENT_Comarca(String ENT_Comarca) {
        this.ENT_Comarca = ENT_Comarca;
    }

    public String getENT_Status() {
        return ENT_Status;
    }

    public void setENT_Status(String ENT_Status) {
        this.ENT_Status = ENT_Status;
    }

    public String getENT_Forum() {
        return ENT_Forum;
    }

    public void setENT_Forum(String ENT_Forum) {
        this.ENT_Forum = ENT_Forum;
    }

    public String getENT_Tipo() {
        return ENT_Tipo;
    }

    public void setENT_Tipo(String ENT_Tipo) {
        this.ENT_Tipo = ENT_Tipo;
    }

    public String getENT_Fone() {
        return ENT_Fone;
    }

    public void setENT_Fone(String ENT_Fone) {
        this.ENT_Fone = ENT_Fone;
    }

    public String getENT_Contato() {
        return ENT_Contato;
    }

    public void setENT_Contato(String ENT_Contato) {
        this.ENT_Contato = ENT_Contato;
    }
}

