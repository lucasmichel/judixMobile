package com.app.alg.judix.util;

/**
 * Created by AndreBTS on 18/07/2015.
 */
public class Constantes {
    public static final String APP_DIR = "Judix";
    //public static final String IMG_DIR = "Imagens";
//    public static final String ANDROID_DOWNLOAD_DIR = "Download";
//    public static final String ANDROID_IMG_DIR = "DCIM/100ANDRO";
}
