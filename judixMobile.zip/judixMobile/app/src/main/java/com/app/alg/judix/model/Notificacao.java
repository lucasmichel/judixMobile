package com.app.alg.judix.model;

/**
 * Created by lucas on 23/04/17.
 */

public class Notificacao {

    private String NOT_ID;
    private String NOT_Telefone;
    private String NOT_Endereco;
    private String NOT_DataEncontro;
    private String NOT_HoraEncontro;
    private String NOT_DataHoraCadastro;
    private String USU_Cadastro_ID;
    private String MAN_ID;
    private String USU_Alteracao_ID;
    private String NOT_DataHoraAlteracao;
    private String MAN_Numero_Processo;


    public String getNOT_ID() {
        return NOT_ID;
    }

    public void setNOT_ID(String NOT_ID) {
        this.NOT_ID = NOT_ID;
    }

    public String getNOT_Telefone() {
        return NOT_Telefone;
    }

    public void setNOT_Telefone(String NOT_Telefone) {
        this.NOT_Telefone = NOT_Telefone;
    }

    public String getNOT_Endereco() {
        return NOT_Endereco;
    }

    public void setNOT_Endereco(String NOT_Endereco) {
        this.NOT_Endereco = NOT_Endereco;
    }

    public String getNOT_DataEncontro() {
        return NOT_DataEncontro;
    }

    public void setNOT_DataEncontro(String NOT_DataEncontro) {
        this.NOT_DataEncontro = NOT_DataEncontro;
    }

    public String getNOT_HoraEncontro() {
        return NOT_HoraEncontro;
    }

    public void setNOT_HoraEncontro(String NOT_HoraEncontro) {
        this.NOT_HoraEncontro = NOT_HoraEncontro;
    }

    public String getNOT_DataHoraCadastro() {
        return NOT_DataHoraCadastro;
    }

    public void setNOT_DataHoraCadastro(String NOT_DataHoraCadastro) {
        this.NOT_DataHoraCadastro = NOT_DataHoraCadastro;
    }

    public String getUSU_Cadastro_ID() {
        return USU_Cadastro_ID;
    }

    public void setUSU_Cadastro_ID(String USU_Cadastro_ID) {
        this.USU_Cadastro_ID = USU_Cadastro_ID;
    }

    public String getMAN_ID() {
        return MAN_ID;
    }

    public void setMAN_ID(String MAN_ID) {
        this.MAN_ID = MAN_ID;
    }

    public String getUSU_Alteracao_ID() {
        return USU_Alteracao_ID;
    }

    public void setUSU_Alteracao_ID(String USU_Alteracao_ID) {
        this.USU_Alteracao_ID = USU_Alteracao_ID;
    }

    public String getNOT_DataHoraAlteracao() {
        return NOT_DataHoraAlteracao;
    }

    public void setNOT_DataHoraAlteracao(String NOT_DataHoraAlteracao) {
        this.NOT_DataHoraAlteracao = NOT_DataHoraAlteracao;
    }


    public String getMAN_Numero_Processo() {
        return MAN_Numero_Processo;
    }

    public void setMAN_Numero_Processo(String MAN_Numero_Processo) {
        this.MAN_Numero_Processo = MAN_Numero_Processo;
    }
}
